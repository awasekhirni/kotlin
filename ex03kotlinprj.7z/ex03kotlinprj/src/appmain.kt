


fun main(){
    val munna = Employee(
        16,
        "Syed Ameese Sadath",
        236792.53F,
        true
    )

    println(munna.empName)
    println(munna.empSalary)

    println("-------------------")

    val aicy = Employee()
    println(aicy.empName)
    println(aicy.empSalary)
    ("---------------")
    val rd =Department()
    println(rd.deptId)
    println(rd.deptName)
}