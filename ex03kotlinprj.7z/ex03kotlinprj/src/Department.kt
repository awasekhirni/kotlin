//default values for arguments
class Department(val deptId:Int=456, val deptName:String="Research"){


}