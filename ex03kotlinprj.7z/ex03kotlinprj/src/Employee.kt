class Employee(val empId:Int, val empName: String, val empSalary:Float, val empIsActive:Boolean) {

    init{
        println("init 1")
    }

    constructor(): this(10,"Syed Awase Khirni",7218.80F, true){
        println("this is secondary constructor")
    }

    init{
        println("init 2")
    }
}