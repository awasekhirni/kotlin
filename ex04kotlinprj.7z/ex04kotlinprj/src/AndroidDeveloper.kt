class AndroidDeveloper (name:String, age:Int, salary:Int):Employee(name,age,salary){
    fun buildAndroidApps(){
        println("AndroidApplication Developer")
    }
}