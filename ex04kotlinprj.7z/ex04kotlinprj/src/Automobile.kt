sealed class Automobile (val type:String){

    class Car:Automobile("Toyota")
    class Truck:Automobile("Volvo")
}

class ElectricCar:Automobile("Tesla")

 fun display(auto:Automobile){
        when(auto){
            is Automobile.Car -> println("${auto.type} is a good car")
            is Automobile.Truck ->
                println("${auto.type} is a good Truck")
            is ElectricCar ->
                println("${auto.type} is a green car")
        }
    }
