class Engine {
    var engineName="Fiat v420 Engine"
    var engineCC=4500

    class Part{
        val shockAbsorber="50tonne"
        val tires="19inch"
    }

}