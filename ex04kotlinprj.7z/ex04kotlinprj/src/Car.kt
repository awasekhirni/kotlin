class Car:IVehicle {
    override fun start() {
        println("car started")
    }

    override fun move() {
    println("car acclerating/moving")
    }

    override fun turn() {
        println("car make a turn")
    }

    override fun stop() {
       println("car makes a stop")
    }

}