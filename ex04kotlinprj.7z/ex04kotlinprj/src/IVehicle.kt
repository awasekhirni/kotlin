interface IVehicle {
    fun start()
    fun move()
    fun turn()
    fun stop()
}