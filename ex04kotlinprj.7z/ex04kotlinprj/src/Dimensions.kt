interface Dimensions {
   val length:Double
    val breadth:Double
}