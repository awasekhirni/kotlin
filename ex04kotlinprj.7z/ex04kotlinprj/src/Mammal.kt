abstract class Mammal:LivingThings() {
    override fun breathe() {
        super.breathe()
    }
}