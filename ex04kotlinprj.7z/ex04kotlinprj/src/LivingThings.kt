open class LivingThings {
   open fun breathe(){
       println("All living things breath")
   }
}