class Horse:Mammal() {
    override fun breathe() {
        super.breathe()
        println("Horse also breathes")
    }
}