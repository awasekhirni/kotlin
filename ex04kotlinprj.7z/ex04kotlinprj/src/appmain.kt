fun main(){
    //nested classes demo
    println(Engine.Part().shockAbsorber)
    println(Engine.Part().tires)
    println(Engine().engineName)


    val userreg=Registration("awasekhirni@gmail.com","testmenow",35,'m')
    println(userreg.email_id)


    //calling custom accessor
    val box = Rectangle(36,63)
    println(box.isSquare)

    //inheritance demo

    val webapp = WebDeveloper("SyedAwase", 35, 8600393)
   webapp.buildWebApp()
    val andre = AndroidDeveloper("SyedAmeese",30, 732922)
    andre.buildAndroidApps()
    val apple = IosDeveloper("SyedAzeez",25, 736362)
    apple.buildAppleMobileApps()



    //interface implementation demo
    val elantra = Car()
    elantra.start()
    elantra.move()
    elantra.turn()
    elantra.stop()


    val boxresult=Compute()
    boxresult.area()
    boxresult.perimeter()


    //data class
    //used to hold some data in it

    data class Product(val prodName:String, val prodPrice:Int, val prodDiscount:Int)

    val sony=Product("XperiaZ", 49000,9000)
    println(sony.toString())


    val highlander = Automobile.Car()
    val man = Automobile.Truck()
    val reva = ElectricCar()

    display(highlander)
    display(man)
    display(reva)



//abstract classes
    val being = LivingThings()
    being.breathe()
    val mustang = Horse()
    mustang.breathe()



}