interface CalculateParameters : Dimensions{
    fun area()
    fun perimeter()
}