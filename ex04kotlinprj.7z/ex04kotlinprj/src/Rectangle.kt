class Rectangle (val height:Int, val width:Int){

 //custom implementation for property accessor
    val isSquare:Boolean
        get(){
            return height == width
        }
}