class WebDeveloper(name:String, age:Int,salary:Int):Employee(name,age,salary) {
    fun buildWebApp(){
        println("I am Web Application Developer")
    }
}