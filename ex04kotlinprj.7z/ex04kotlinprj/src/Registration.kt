class Registration (email:String, pwd:String, age:Int, gender:Char) {
     //custom getter
    var email_id:String = email
    get(){
        return field.toUpperCase()
    }

    var password:String=pwd
     set(value){
         field=if(value.length >8) value else throw IllegalArgumentException("Password is short")
     }

    var age: Int = age
        // Custom Setter
        set(value) {
            field = if(value > 18 ) value else throw IllegalArgumentException("Age must be 18+")
        }
    var gender : Char = gender
        //Custom Setter
        set (value){
            field = if(value == 'M') value else throw IllegalArgumentException("User should be male")
        }



}