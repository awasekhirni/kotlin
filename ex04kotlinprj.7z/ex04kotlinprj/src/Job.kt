abstract class Job (val jobTitle:String, val jobDesc:String){

 //abstract property
    abstract var jobSalary:Double
    abstract fun startDate(date:String)

    //non-abstract method
    fun jobInfo(){
        println("Job Title: $jobTitle")
        println("Job Description: $jobDesc")
        println("Annual Salary: $jobSalary")
    }
}