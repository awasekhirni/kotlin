class GlassdoorJob (jobTitle:String, jobDesc:String): Job(jobTitle,jobDesc){
    override var jobSalary: Double = 9000000.90

    override fun startDate(date: String) {
        println("Expected join date is $date")
    }

}