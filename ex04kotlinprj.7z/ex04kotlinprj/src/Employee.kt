//base class
open class Employee (name:String, age:Int, salary:Int) {

    init{
        println("$name, $age, $salary")
    }
}