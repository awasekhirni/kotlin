class Compute:CalculateParameters {
    override val length:Double
        get()=10.0
    override val breadth:Double
        get()=15.0

    override fun area() {
        val result= length*breadth
   println("Area is $result")
    }

    override fun perimeter() {
      val result= 2*(length+breadth)
        println("perimeter is $result")
    }


}