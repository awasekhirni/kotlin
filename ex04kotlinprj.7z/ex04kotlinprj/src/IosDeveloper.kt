class IosDeveloper (name:String, age:Int, salary:Int):Employee(name, age, salary){
    fun buildAppleMobileApps(){
        println("Building ios mobile applications")
    }
}