package com.enterprise.repository

import org.jetbrains.exposed.sql.Table

object Employees:Table(){
    val id=integer("id").primaryKey().autoIncrement()
    val name=varchar("name",100)
    val email= varchar("email",250)
    val city = varchar("city",250)

}