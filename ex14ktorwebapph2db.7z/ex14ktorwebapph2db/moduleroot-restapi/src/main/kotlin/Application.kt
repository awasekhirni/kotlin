package com.enterprise

import com.enterprise.route.appRoutes
import freemarker.cache.ClassTemplateLoader
import io.ktor.application.*
import io.ktor.response.*
import io.ktor.request.*
import io.ktor.routing.*
import io.ktor.http.*
import io.ktor.content.*
import io.ktor.features.StatusPages
import io.ktor.freemarker.FreeMarker
import io.ktor.http.content.*

fun main(args: Array<String>): Unit = io.ktor.server.cio.EngineMain.main(args)

@Suppress("unused") // Referenced in application.conf
@kotlin.jvm.JvmOverloads
fun Application.module(testing: Boolean = false) {


    install(FreeMarker){
        templateLoader = ClassTemplateLoader(this::class.java.classLoader, "templates")
    }

    install(Routing){
        appRoutes()
    }
    install(StatusPages){
        this.exception<Throwable>{e->
            call.respondText(e.localizedMessage,ContentType.Text.Plain)
            throw e
        }
    }

}

