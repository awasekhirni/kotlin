package com.enterprise.models

data class Employee(
    val id: Int,
    val name:String,
    val email:String,
    val city: String
)

