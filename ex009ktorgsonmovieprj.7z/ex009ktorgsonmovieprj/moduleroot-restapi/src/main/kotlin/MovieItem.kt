package com.enterprise

import java.time.LocalDate

data class MovieItem(
    val title:String,
    val imdbId:String,
    val releaseDate:String,
    val releaseCountry: String,
    val releaseYear: Int,
    val releaseMonth: Int,
    val releaseDay: Int

)

val movie1=MovieItem(
     "Wings",
"tt0018578",
"1927-05-19T05:00:00.000Z",
"USA",
 1927,
 4,
 19

)

val movie2=MovieItem(
     "The Broadway Melody",
 "tt0019729",
"1929-02-01T05:00:00.000Z",
 "USA",
 1929,
 1,
 1

)


val movie3=MovieItem(

    "All Quiet on the Western Front",
"tt0020629",
"1930-04-21T04:00:00.000Z",
 "USA",
 1930,
 3,
 21
)