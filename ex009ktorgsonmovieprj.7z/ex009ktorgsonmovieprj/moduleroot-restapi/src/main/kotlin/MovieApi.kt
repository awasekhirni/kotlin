package com.enterprise

import io.ktor.response.respond
import io.ktor.application.call
import io.ktor.routing.Routing
import io.ktor.routing.get
import io.ktor.routing.route

fun Routing.movieApi(){

    route("/api/movies"){
        get("/"){
            call.respond(movies)
        }
    }
}