package com.enterprise

import io.ktor.application.*
import io.ktor.response.*
import io.ktor.request.*
import io.ktor.routing.*
import io.ktor.http.*
import io.ktor.content.*
import io.ktor.http.content.*
import io.ktor.gson.*
import io.ktor.features.*

fun main(args: Array<String>): Unit = io.ktor.server.cio.EngineMain.main(args)

val movies = listOf(movie1,movie2,movie3)
@Suppress("unused") // Referenced in application.conf
@kotlin.jvm.JvmOverloads
fun Application.module(testing: Boolean = false) {
   install(Routing){
        movieApi()
   }
    install(StatusPages){
        this.exception<kotlin.Throwable>{e->
            call.respondText(e.localizedMessage,ContentType.Text.Plain)
            throw e
        }
    }
    install(ContentNegotiation){
        gson {
            setPrettyPrinting()

            disableHtmlEscaping()
        }
    }

}

