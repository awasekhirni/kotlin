class ProductFactory {
   var counter =0
    private val aluminiumFactory =AluminiumFactory()
    private val steelFactory=SteelFactory()
    private val woodFactory = WoodFactory()

    fun createProduct(productName:String, productType:String, productSpec:String):IProduct{
        return when(productType.trim().toLowerCase()){
            "wood"-> woodFactory.createWoodProduct(productName,productType,productSpec)
            "steel"->steelFactory.createSteelProduct(productName,productType,productSpec)
            "aluminium"->aluminiumFactory.createAluminumProduct(productName,productType,productSpec)
            else -> throw RuntimeException("unknown product type specified")
        }


    }

}