class SteelBox(productName: String, productType: String, productSpec: String) :IProduct{
    override val productName: String
        get() = "SteelBox"
    override val productType: String
        get() = "Steel"
    override val productSpec: String
        get() = "4ft by 4ft"

}