class AluminiumBox(productName: String, productType: String, productSpec: String) :IProduct {
    override val productName: String
        get() = "Aluminium Box"
    override val productType: String
        get() = "Aluminium"
    override val productSpec: String
        get() = "4ftx4ft"

}