interface IProduct {

    val productName:String
    val productType:String
    val productSpec:String



}