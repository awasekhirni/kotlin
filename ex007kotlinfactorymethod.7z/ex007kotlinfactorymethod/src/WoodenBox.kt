class WoodenBox(productName: String, productSpec: String, productType: String) :IProduct {
    override val productName: String
        get() = "WoodenBox"
    override val productType: String
        get() = "Wooden"
    override val productSpec: String
        get() = "4ft by 4ft"


}