class AluminiumFactory {
    fun createAluminumProduct(productName:String, productType:String, productSpec:String):IProduct{
        return AluminiumBox(
            productName = productName,
            productType = productType,
            productSpec = productSpec
        )
    }
}