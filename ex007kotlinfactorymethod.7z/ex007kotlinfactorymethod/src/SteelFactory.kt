class SteelFactory {
    fun createSteelProduct(productName:String, productType:String, productSpec:String):IProduct{
        return SteelBox(
            productName =productName,
            productType =productType,
            productSpec =productSpec
        )
    }
}