class WoodFactory {
  fun createWoodProduct(productName:String, productType:String, productSpec:String):IProduct{
      return WoodenBox(productName=productName, productType=productType, productSpec=productSpec)
  }
}