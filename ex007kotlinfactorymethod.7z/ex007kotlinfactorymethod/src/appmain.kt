fun main(args:Array<String>){

    val factory = ProductFactory()
    val s = factory.createProduct("Steelbox","steel","4ft by 4ft")
    println(s.toString())
    println("""${s.productName},${s.productType},${s.productSpec})""")
}