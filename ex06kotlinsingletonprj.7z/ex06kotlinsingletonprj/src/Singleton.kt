object Singleton {
    init {
        println("Singleton class invoked!")
    }

    var variableName = " I am a singletonvariable"

    fun printVarName(){
        println(variableName)
    }
}


