//singleton implementation in kotlin

fun main(args:Array<String>){
    Singleton.printVarName()
    Singleton.variableName="Syed Awase Khirni"

    MySQLHandler.createConnection()
    MySQLHandler.disconnect()


    //iterate and check
    for (i in 1..20){
        println(Singular.increment())
    }
}