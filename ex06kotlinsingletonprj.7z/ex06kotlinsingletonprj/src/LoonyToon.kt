class LoonyToon private constructor() {

 companion object {
     private val INSTANCE: LoonyToon= LoonyToon()
     @JvmStatic
     fun getInstance():LoonyToon = INSTANCE
 }
}