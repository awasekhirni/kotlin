import java.util.concurrent.atomic.AtomicInteger

object Singular {

 init{
     println("This class has been accessed for the first time")

 }

    private val counter = AtomicInteger(0)
    fun increment() = counter.incrementAndGet()
}