object MySQLHandler {

    val instanceName:String="MySQLDialect"
    val dbName:String ="ex006kotlinDB"
    val port:Int =3306

    fun createConnection(){
        println("connect to the database")
    }

    fun disconnect(){
        println("disconnect the database")
    }
}