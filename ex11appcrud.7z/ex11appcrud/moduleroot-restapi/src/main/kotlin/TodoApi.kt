package com.enterprise


import io.ktor.response.respond
import io.ktor.application.call
import io.ktor.http.HttpStatusCode
import io.ktor.request.receive
import io.ktor.routing.Routing
import io.ktor.routing.get
import io.ktor.routing.*
import io.ktor.routing.route



fun Routing.todoApi(){
    route("/api/todos"){
//        header("Accept","application/json"){
//         get() {
//
//         }
//        }
        get("/"){
            call.respond(todos)
        }

        //findbyId
        get("/{id}"){
            val id:String = call.parameters["id"]!!
            try {
                val todo: TodoItem = todos[id.toInt()]
                call.respond(todo)
            }catch (e:Throwable){
                call.respond(HttpStatusCode.NotFound)
            }
        }

        post("/"){
            val todo = call.receive<TodoItem>()
            val newTodo= TodoItem(
                todos.size+1,
                todo.title,
                todo.details,
                todo.assignedTo,
                todo.dueDate,
                todo.importance
            )
            todos = todos + newTodo
            call.respond(HttpStatusCode.Created,todos)
        }


        //update
        put("/{id}"){
            val id=call.parameters["id"]
            if (id==null){
                call.respond(HttpStatusCode.BadRequest){
                    return@respond
                }
                val foundItem=todos.getOrNull(id?.toInt()!!)
                if(foundItem==null){
                    call.respond(HttpStatusCode.NotFound)
                    return@put
                }

                val todo = call.receive<TodoItem>()
                todos = todos.filter{it.id != todo.id}
                todos = todos + todo
                call.respond(HttpStatusCode.NoContent)
            }
        }


        delete("/{id}"){
            val id=call.parameters["id"]
            if (id == null){
                call.respond(HttpStatusCode.BadRequest)
                return@delete
            }

            val foundItem=todos.getOrNull(id.toInt())
            if (foundItem == null){
                call.respond(HttpStatusCode.NotFound)
                return@delete
            }

            todos = todos.filter{it.id !=id.toInt()}
            call.respond(HttpStatusCode.NoContent)
        }


    }

}
// another approach
//fun Routing.todoApi(){
//    route("/api"){
//        route("/todos"){
//            get("/"){
//                call.respond(todos)
//            }
//        }
//    }
//}

//alt approach
//fun Routing.todoApi(){
//    route("/api"){
//        route("/todos",HttpMethod.Get){
//            handle{
//                call.respond(todos)
//            }
//        }
//    }
//}

