enum class DAYS(val isWeekend:Boolean=false) {
    SUNDAY(true),
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY(true);

    companion object{
        fun today(obj:DAYS):Boolean{
            return obj.name.compareTo("SATURDAY")==0 || obj.name.compareTo("SUNDAY")==0
        }
    }

}