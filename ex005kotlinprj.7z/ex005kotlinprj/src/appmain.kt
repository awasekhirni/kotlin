fun main(){

    for(day in DAYS.values()) {
        println("${day.ordinal} = ${day.name} and is weekend ${day.isWeekend}")
    }
    val today = DAYS.MONDAY;
    println("Is today a weekend ${DAYS.today(today)}")

    Seasons.Summer.info()

    //extension functions
    fun Shape.perimeter():Double{
        return 2*Math.PI*radius;
    }


    val newShape = Shape("circle", 5.0)
    println("Area of the circle is ${newShape.area()}")

    println("perimeter of the circle is ${newShape.perimeter()}")

}