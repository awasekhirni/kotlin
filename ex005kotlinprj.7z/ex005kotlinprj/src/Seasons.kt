enum class Seasons(var weather:String) {
    Summer("hot and humid"){
        override fun info(){
            println("Hot and humid long days of the year!")
        }
    },
    Winter("cold and windy"){
        override fun info(){
            println("Cold and Windy Short days of the year!")
        }
    },
    Rainy("stormy and windy"){
        override fun info(){
            println("stormy and windy days of the year!")
        }
    };
    abstract fun info()
}