class Shape (val name:String, val radius:Double) {
    fun area():Double{
        return Math.PI*radius*radius;
    }
}