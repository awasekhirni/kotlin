/*
Copyright 2017-18 Syed Awase Khirni
www.sycliq.com www.territorialprescience.com
awasekhirni@gmail.com 9035433124
 */

fun greetinArabic()="Ahlan wa sahlan! As-Salam alaikum"

fun sayinUrdu()="Aadab! as-salam alaikum"

fun sayinGerman(){
    println("Gut Morgen!")
}

fun sayinEnglish(){
    println("GoodMorning!")
}

fun sayinFrench(personName:String){
    //immutable type string
    val greeting = "Bonjour! Monsieur:"+personName
    println(greeting)
}

fun sayinChinese(personName:String){
    //immutable type string
    //string interpolation
    val greeting = "Ni hao! $personName"
    println(greeting)
}

fun main(){
    println("function demo using kotlin! -Syed Awase Khirni")
    println(sayinUrdu())
    println(greetinArabic())
    sayinGerman()
    sayinEnglish()
    sayinFrench("SyedAwase")
    sayinChinese("Bisheng Yang!")


    //arrays in kotlin
    val marketBasket = arrayOf("milk","bread","eggs","beer","diaper","shaving cream","garlic butter")
    println(marketBasket.size)
    println(marketBasket[2])
    println(marketBasket.get(0))

    //for loop
    for (item in marketBasket){
        println(item)
    }

    //foreach loop
    marketBasket.forEach{item:String ->
    println(item)
    }

    //foreachIndex
    marketBasket.forEachIndexed { index, item ->
        println("the items in the basket :$item is at index: $index")
    }

   




    //list collection in kotlin
    val fruitsBasket= listOf("banana","apple","orange","kiwi","pineapple","watermelon")
    fruitsBasket.forEach{item ->
        println(item)
    }

    //takeWhile() takes the items upto but
    //excluding the first one not matching the predicate
    println(fruitsBasket.takeWhile{
        !it.startsWith("a")
    })


    //takeLastWhile() takes a range of items
    // matching the predicate from the end
    println(fruitsBasket.takeLastWhile{
        it != "berries"
    })


    println(fruitsBasket.slice(1..3))
    println(fruitsBasket.slice(0..4 step 2))
    println(fruitsBasket.slice(setOf(0,3,5)))
    println(fruitsBasket.take(2))
    println(fruitsBasket.takeLast(2))
    println(fruitsBasket.drop(2))
    println(fruitsBasket.dropLast(2))


    //dropWhile() return the items from the first
    // one not matching the predicate to the end
    println(fruitsBasket.dropWhile{it.length==5})

    println(fruitsBasket.dropLastWhile{it.contains("k")})

    //map collection in kotlin
    val postcodeMap= mapOf(
        560043 to "kalyan nagar",
        560036 to "marthahalli",
        560100 to "whitefield",
        560099 to "jpnagar"
    )

   postcodeMap.forEach{key,value-> println("$key => $value")}

    //mutable list

    val fakeNews = mutableListOf("RepublicTV","ANINews","IndiaToday","ZeeNews","SudarshanTV")
fakeNews.add("TimesofIndia")
    fakeNews.forEach { news ->
    println("$news")
    }

    //mutable maps
    val broMap =mutableMapOf(1 to "Awase",2 to "Ameese", 3 to "Azeez")
    broMap.put(4, "babla")
    broMap.forEach{ bro ->
        println("$bro")
    }


    //variable arguments to functions
    onlineBasket("amazon","milk","bread","butter","eggs","beer")

    onlineBasket("grofers",*marketBasket)

    //sets demo
    val crackers=setOf("brittania","50-50","parle")
    for(item in crackers){
        println(item)
    }
    println("number of elements+ ${crackers.count()}")


    //mutable set of integers
    val scores = mutableSetOf<Int>(23,12,56,72,182,49,89)
    scores +=listOf(48,20)

    for(score in scores){
        println(score)
    }
    println("scores is Empty check : ${scores.isEmpty()}")

    //hashmap
    var superHumanMovies =HashMap<String,Int>()
    superHumanMovies.put("Thor",129893)
    superHumanMovies.put("IronMan",812378)
    superHumanMovies.put("Batman",267632)
    superHumanMovies.put("Spiderman",8912938)

    for(key in superHumanMovies.keys){
        println("Element at key $key:${superHumanMovies[key]}")
    }


}

fun onlineBasket(companyName:String, vararg marketBasket:String){
    marketBasket.forEach{item ->
        println("company:$companyName has the following items in the cart: $item")
    }
}