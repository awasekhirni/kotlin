package com.enterprise

import org.jetbrains.exposed.sql.Table

object Products: Table(){
    val productId=text ("productid")
    val productName= text("productname")
    val productDesc = text("productdesc")
    val productPrice = integer("productprice")
}