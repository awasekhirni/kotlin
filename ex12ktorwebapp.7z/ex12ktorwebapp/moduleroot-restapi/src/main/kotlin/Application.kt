package com.enterprise

import io.ktor.application.*
import io.ktor.response.*
import io.ktor.request.*
import io.ktor.routing.*
import io.ktor.http.*
import io.ktor.content.*
import io.ktor.http.content.*
import io.ktor.features.*
import com.fasterxml.jackson.core.util.*
import com.fasterxml.jackson.databind.*
import com.fasterxml.jackson.datatype.jsr310.*
import io.ktor.jackson.jackson


fun main(args: Array<String>): Unit = io.ktor.server.cio.EngineMain.main(args)

@Suppress("unused") // Referenced in application.conf
@kotlin.jvm.JvmOverloads
fun Application.module(testing: Boolean = false) {

    initDB()

    install(DefaultHeaders)

    install(Routing){
        productApi()
    }

    install(StatusPages){
        this.exception<Throwable>{ e ->
            call.respondText(e.localizedMessage,ContentType.Text.Plain)
            throw e

        }
    }

    install(ContentNegotiation){
        jackson{
            enable(SerializationFeature.INDENT_OUTPUT)
        }
    }




}

