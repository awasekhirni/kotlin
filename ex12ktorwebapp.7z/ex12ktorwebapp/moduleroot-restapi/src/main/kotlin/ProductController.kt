package com.enterprise

import com.enterprise.Products.productId
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import kotlin.collections.ArrayList

class ProductController {

    fun getAll(): ArrayList<Product> {
        val products: ArrayList<Product> = arrayListOf()
        transaction {
            Products.selectAll().map {
                products.add(
                    Product(
                        productId = it[Products.productId],
                        productName = it[Products.productName],
                        productDesc = it[Products.productDesc],
                        productPrice = it[Products.productPrice]
                    )
                )
            }
        }
        return products
    }

    fun insert(product:ProductDTO){
        transaction{
            Products.insert{
                it[productId]=product.productId
                it[productName]= product.productName
                it[productDesc]= product.productDesc
                it[productPrice]=product.productPrice
            }
        }
    }

    fun update(product:ProductDTO, productId: String){
        transaction{
            Products.update({Products.productId eq productId}){
                it[productName]= product.productName
                it[productDesc]= product.productDesc
                it[productPrice]=product.productPrice
            }
        }
    }


    fun delete(productId: String){
        transaction{
            Products.deleteWhere{Products.productId eq productId}
        }
    }


}