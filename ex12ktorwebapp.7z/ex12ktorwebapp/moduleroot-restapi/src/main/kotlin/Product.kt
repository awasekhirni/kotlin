package com.enterprise
import java.util.*

data class Product(
    val productId :String,
    val productName:String,
    val productDesc:String,
    val productPrice:Int
)

data class ProductDTO(
    val productId: String,
    val productName:String,
    val productDesc:String,
    val productPrice:Int
)