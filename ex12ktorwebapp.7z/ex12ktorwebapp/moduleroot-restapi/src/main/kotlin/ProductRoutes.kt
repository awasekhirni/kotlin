package com.enterprise

import io.ktor.response.respond
import io.ktor.application.call
import io.ktor.http.HttpStatusCode
import io.ktor.request.receive
import io.ktor.routing.Routing
import io.ktor.routing.route
import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import io.ktor.http.ContentType
import io.ktor.http.HttpMethod
import io.ktor.response.respondText
import org.jetbrains.exposed.sql.Database


fun initDB(){
    val config = HikariConfig("/hikari.properties")
    config.schema="public"
    val ds = HikariDataSource(config)
    Database.connect(ds)
}


val productController = ProductController()

fun Routing.productApi(){
    route("/api"){

        route("/", HttpMethod.Get){
            handle{
                call.respondText("Product Api with DB",ContentType.Text.Plain)
            }
        }

        route("/products",HttpMethod.Get){
            handle{
                call.respond(productController.getAll())
            }
        }


        route("/products", HttpMethod.Post){
            handle{
                val productDto=call.receive<ProductDTO>()
                productController.insert(productDto)
                call.respond(HttpStatusCode.Created)
            }
        }

        route("/products/{id}",HttpMethod.Put){
            handle{
                val id: String? = call.parameters["id"]
                val productDTO= call.receive<ProductDTO>()
                if (id != null) {
                    productController.update(productDTO,id)
                }
                call.respond(HttpStatusCode.OK)
            }
        }


        route("/products/{id}",HttpMethod.Delete){
            handle{
                val id:String?=call.parameters["id"]
                if (id != null) {
                    productController.delete(id)
                }
                call.respond(HttpStatusCode.OK)
            }
        }


    }
}
