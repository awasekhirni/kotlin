package com.enterprise

import io.ktor.jackson.*
import com.fasterxml.jackson.core.util.*
import com.fasterxml.jackson.databind.*
import com.fasterxml.jackson.databind.annotation.JsonDeserialize
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer
import com.fasterxml.jackson.datatype.jsr310.*
import com.fasterxml.jackson.datatype.jsr310.deser.key.LocalDateKeyDeserializer
import java.time.*
import java.time.LocalDate




data class TodoItem(
    val title:String,
    val details:String,
    val assignedTo:String,
    val dueDate: LocalDate,
    val importance:Int
)

val todo1 = TodoItem(
    "Kotlin Programming Language",
    "JVM Language developed by JetBrains",
    "Syed Awase Khirni",
//    @JsonSerialize(using= ToStringSerializer::class)
//    @JsonDeserialize(using= LocalDateKeyDeserializer::class)
    LocalDate.of(2017,12, 3),
    9
)

val todo2 = TodoItem(
    "Scala Programming Language",
    "JVM language",
    "Syed Awase Khirni",
    LocalDate.of(2017,12,12),
    9
)

val todo3=TodoItem(
    "Clojure Programming Language",
    "JVM language",
    "Syed Awase Khirni",
    LocalDate.of(2017,12,3),
    8
)

val todo4=TodoItem(
    "Apache Groovy Programming Language",
    "JVM Language",
    "Syed Awase Khirni",
    LocalDate.of(2017,12,26),
    8
)


